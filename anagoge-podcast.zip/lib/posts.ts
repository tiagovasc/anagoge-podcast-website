const posts = [
  {
    title: "The Return of the Sacred",
    side_title: "John Cottingham",
    youtube_id: "l-nSyXGbO24",
    description:
      "John Cottingham is Professor Emeritus of Philosophy at the University of Reading and an Honorary Fellow of St John's College, Oxford. Renowned for his work on Descartes, moral philosophy, and the philosophy of religion, he has authored over thirty books, including *The Spiritual Dimension*, *Why Believe?*, and *Philosophy of Religion: Towards a More Humane Approach*. His scholarship bridges analytic rigor with a deep concern for the emotional and spiritual dimensions of human life.\n\nHis latest book is *In Search of the Soul: A Philosophical Essay*: https://press.princeton.edu/books/har...\n\nIn this episode, we explore Cottingham's call for a more 'humane' philosophy of religion—one that acknowledges the roles of emotion, ritual, and embodied practice in shaping belief. He critiques the overly abstract methods of contemporary philosophy and argues that genuine understanding of the sacred requires engaging the full range of human experience. We discuss how rituals and worship practices can be seen not merely as symbolic acts but as vital expressions of our search for meaning and connection.\n\nWe also cover the interplay between science and spirituality, examining how a scientific worldview can either harm or coexist with a sense of the transcendent. Cottingham shares insights on the human longing for the good and how this desire points beyond material explanations, inviting a reevaluation of the role of religion in modern life.",
    timestamps:
      '0:00:00 - Introduction\n0:02:59 - Cottingham\'s Philosophical Journey & "Humane Perspective"\n0:06:39 - Philosophy\'s Accessibility & Bridging the Gap for Non-Specialists\n0:12:38 - The Starting Points of Religion\n0:17:19 - Critiquing Scientism & the Need for a Broader Epistemology\n0:25:33 - Grappling with Christian Doctrine vs. Science\n0:38:49 - The Nature of "The Good": Platonic vs. Christian Conceptions\n0:49:10 - The Necessity of Religious Practice\n0:54:17 - Psychedelics and Spirituality\n1:04:05 - Cottingham\'s Career Reflections\n1:08:14 - Closing Remarks',
    apple_link: "https://podcasts.apple.com/si/podcast/anagoge-podcast/id1512482918",
    spotify_link: "https://open.spotify.com/show/4ifa95kknLrUQblYTUMQ7T",
    youtube_link: "https://www.youtube.com/watch?v=l-nSyXGbO24",
    google_link: "",
  },
  {
    title: "The Neuroscience of Emotions",
    side_title: "Dr. Joseph LeDoux",
    youtube_id: "xcb6KsGunCY",
    description:
      "In this episode, I have the pleasure of speaking with Dr. Joseph LeDoux, a world-renowned neuroscientist whose research focuses on survival circuits and their impacts on emotions like fear and anxiety. He is the Henry and Lucy Moses Professor of Science at New York University and director of the Emotional Brain Institute.\n\nOur conversation delves into Dr. LeDoux's early work with split-brain patients, leading to explorations of consciousness. He shares his journey from studying humans to animal models, particularly regarding fear and anxiety. We discuss the nature of emotions, contrasting the universal, biological view with the constructivist theory. Dr. LeDoux emphasizes that while innate circuits control behavior, the conscious emotion experience is a cognitive interpretation influenced by personal narratives and cultural schemas. We also address attributing emotional states to animals, underlining the importance of distinguishing physiological responses from conscious experiences and the risks of anthropomorphizing animal behavior.\n\nThis episode is a deep dive into human emotion and brain functions, offering insights from a leading expert. Whether you're a neuroscience student, a curious learner, or interested in understanding human emotion complexities, this conversation is a valuable resource.",
    timestamps:
      "0:00:00 Start\n0:00:37 Introduction\n0:03:05 Nature of emotions: biological vs. constructed theories\n0:05:52 Neuroscience of emotions and foundation with split-brain patients\n0:20:23 Cognitive elements in emotions and the disconnect between physiological responses and conscious emotion experience\n0:28:04 Role of biological neural circuits in emotional responses\n0:31:42 Emotional models and how emotional experiences are based on interpretation and shaped by language\n0:40:24 Attributing emotional states to animals and consciousness in mammals\n0:57:25 Joseph's career, intersection of neuroscience and music, and his upcoming book",
    apple_link:
      "https://podcasts.apple.com/si/podcast/the-neuroscience-of-fear-and-anxiety-joseph-ledoux/id1512482918?i=1000622971714",
    spotify_link: "https://open.spotify.com/episode/28lhXfSvVJIASYWQStVBOG?si=tgW2F3ccSGeJt_wEaM6SVg",
    youtube_link: "https://youtu.be/xcb6KsGunCY",
    google_link: "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M",
  },
  {
    title: "Learning & Teaching Philosophy",
    side_title: "Gregory Sadler",
    youtube_id: "gLwN0Cb3Zk8",
    description:
      "In this episode, I talk with Dr. Gregory Sadler, likely the most influential philosophy educator. Sadler earned an M.A. and a Ph.D. in Philosophy from Southern Illinois University. He is the Founder of ReasonIO, a consulting company providing philosophy content, training, and consulting services.\n\nHe has reached impressive popularity on YouTube, and his channel has over 130,000 subscribers and 13 million views. He has helped me digest challenging thinkers with fantastic lectures explaining the main concepts while providing additional context and insights. His channel is an absolute gold mine for anyone interested in philosophy.\n\nWe talk about the process of learning philosophy, the importance of good teachers, considerations about translated works, secondary literature, philosophical biases, truth, and much more. It was a very engaging conversation and one of my favorite episodes!",
    timestamps:
      "0:00 Start\n0:56 Introduction\n4:23 Sadler's expertise and background\n7:08 Sadler's journey in philosophy\n14:06 Being a good teacher\n18:46 Students from non-philosophical backgrounds\n21:02 Stoicism, Sartre, and Nietzsche in Sadler's philosophy views\n25:03 Importance of the original language in philosophical works\n38:08 Death of philosophy\n49:19 Trade-offs between primary and secondary literature\n59:29 Philosophical biases and autodidactism\n1:06:20 Intersection of truth in philosophy and religion",
    apple_link:
      "https://podcasts.apple.com/si/podcast/learning-teaching-philosophy-gregory-sadler-anagoge/id1512482918?i=1000609065886",
    spotify_link: "https://open.spotify.com/episode/6iTvjpBODnZQUGwl47LrM6?si=atp0zehaSAuTX9cX0goI9Q",
    youtube_link: "https://www.youtube.com/watch?v=gLwN0Cb3Zk8",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/OTE4M2U4ZjQtODFiNy00NzQwLWI3MjEtOGNhNzgyODRhMWU4?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Phenomology, 4E Cog-Sci & Awe",
    side_title: "Shaun Gallagher",
    youtube_id: "h3EfbUS6OFU",
    description:
      "Anagoge Podcast is now over 1 year old! Thank you everyone for listening.\n\nShaun Gallagher is the Lillian and Morrie Moss Professor of Excellence in Philosophy at the University of Memphis. His areas of research include phenomenology and the cognitive sciences.\n\nIn this episode, we talk about Shaun's background, the nature of phenomenology and cognitive science, the role of embodiment and action, and Shaun's research about the overview effect; the awe astronauts feel during spaceflight when seeing Earth.",
    timestamps:
      "0:00 Start\n00:23 Introduction\n02:17 Shaun's background in philosophy\n05:49 Shaun's background in cognitive science\n07:24 Interdisciplinarity and Cog-Sci\n10:27 The paradox of phenomenology \n17:32 Scientific vs philosophical methods in phenomenology \n21:32 Cog-Sci as an example of the role of philosophy in science\n26:47 Existentialism in phenomenology \n32:25 Embodied Cog-Sci and psychopathology \n36:39 Virtual reality for therapy \n40:16 What's 4E Cognitive Science?  \n53:35 4E Cognitive Science and Buddhism\n58:45 Varela and Dalai Lama - Mind & Life Institute\n1:00:22 Metaphysical tensions of Buddism and Western Science\n1:04:00 Awe in the overview effect\n1:10:45 Differences in present and future reporting\n1:14:40 Background of the awe experience\n1:17:11 Feeling of unity\n1:20:05 Connections with psychedelic and religious experiences\n1:25:26 Enactivist Cognition \n1:31:22 Critique of Heidegger of social cognition\n1:35:17 History of embodiment",
    apple_link:
      "https://podcasts.apple.com/si/podcast/phenomenology-4e-cog-sci-awe-shaun-gallagher/id1512482918?i=1000562281767",
    spotify_link: "https://open.spotify.com/episode/3JFOECrUXndXqq7Ft6over?si=M4C7Gcf6QV-OAfynZn9f6w",
    youtube_link: "https://www.youtube.com/watch?v=h3EfbUS6OFU",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/ZDliZDMxYWYtN2M0NC00NmJkLThkZTUtNjI1Mjc1OTM1NDI4?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Revolutionizing Psychology",
    side_title: "Gregg Henriques",
    youtube_id: "vIoMVT_7fRM",
    description:
      "In this episode, I talk with Gregg Henriques about the problem of psychology and the solution he has been working on for 20 years. We covered the bulk of his theory in the first half of the episode, and in the second half, we do a deep dive into cognitive behavioural therapy, including Gregg's experience with it and some controversies in one of the major studies published about CBT.\n\nGregg Henriques is a Full Professor and a core faculty member in James Madison University's Combined-Integrated Clinical and School Psychology Doctoral Program. He teaches courses on integrative/unified psychotherapy, personality, social, and cognitive psychology. He developed the Unified Theory Of Knowledge (UTOK), which consists of eight key ideas that Henriques results in a much more unified vision of science, psychology and philosophy.",
    timestamps:
      "0:00:00 Start\n0:00:45 Useless introduction\n0:06:00 The enlightenment gap\n0:12:56 The problem of psychology\n0:22:34 Why evolutionary psychology can't be the answer\n0:32:15 The tree of knowledge\n0:39:09 Emergence and complexity dynamics\n0:45:57 Comparing it to memetics\n0:50:08 Justification hypothesis\n0:53:08 Dan Sperber and Hugo Mercier\n1:01:41 The influence matrix\n1:10:29 Children social intellgience\n1:12:26 Variation of the influence matrix\n1:18:47 Connection with Haidt\n1:20:57 Empirical backing\n1:26:47 Cognitive Behavioral Therapy\n1:47:03 Cognitive vs Non-Cognitive Therapy\n1:55:52 Rigidity vs pseudoscience in therapy\n2:02:33 Conclusion",
    apple_link:
      "https://podcasts.apple.com/si/podcast/gregg-henriques-revolutionizing-psychology/id1512482918?i=1000547424518",
    spotify_link: "https://open.spotify.com/episode/7dIIFuaRTlv0HRk0mqMJ7j?si=EZgX21IcSWCbpSGcVZz8Aw",
    youtube_link: "https://www.youtube.com/watch?v=vIoMVT_7fRM",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/NmJkMTkwNjItNzcyNC00MmY5LTk2ODQtMDg3MTBlYmQ0MmE0?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Foundations & Absurdities of Science",
    side_title: "Michael Strevens",
    youtube_id: "5Rr0S8YsYyc",
    description:
      'Michael Strevens teaches philosophy of science at New York University. His work revolves around the nature of science, covering topics such as scientific explanation, complex systems, and probability. In his book "The Knowledge Machine" he explains why science is so successful at creating knowledge and why it took so long for humans to come up with it.\n\nIn this episode, we talk about the origins of science, philosophy of science, the contributions and flaws of Karl Popper and Thomas Kuhn, what makes science special and some odd contradictions at the core of scientific thinking.',
    timestamps:
      "0:00:53 Introduction\n0:03:19 The origins of science\n0:08:01 Karl Popper and Thomas Kuhn\n0:16:52 What Popper and Kuhn were missing\n0:21:43 Sociology of science\n0:25:49 Contributions of philosophy of science\n0:32:42 Bayesian probability\n0:35:08 What makes science special?\n0:41:59 The irrationality of science\n0:46:18 Aesthetic and theological motivations in science\n0:48:43 Caloric fluid vs kinetic theory of heat\n0:58:08 Creativity in science\n1:00:14 The tediousness of extreme detail\n1:04:49 Can science make truth claims?\n1:11:32 Philosophy of quantum mechanics\n1:15:49 The biggest challenge of science",
    apple_link:
      "https://podcasts.apple.com/si/podcast/michael-strevans-foundations-and-absurdities-of-science/id1512482918?i=1000543722537",
    spotify_link: "https://open.spotify.com/episode/2Kn6MqWyT5fCstFpIz6mMF?si=gJUuv35hQjSgIBWscQTEuw",
    youtube_link: "https://www.youtube.com/watch?v=5Rr0S8YsYyc",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/Y2E4NzA1NjctYjdmZi00OTJmLWI3MzQtNzE4MTIwMTdhNTgx?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Music, Ancient Greece, and Whitehead",
    side_title: "Nathan Dufour",
    youtube_id: "Qhueoc4hQr8",
    description:
      "Nathan Dufour is a writer, musician, video artist and activist. He produces music videos on YouTube about philosophical ideas and teaches Latin language and Greek Civilization at City College of New York. He received a PhD in Classics from CUNY's Graduate Center.\n\nIn the first half, we talk about the relationship between music and philosophy, the performative aspect of art, philosophy's origins and how it connects to music, classics, and western civilization.\n\nIn the second half, we cover Plato and Whitehead, which was Nathan's PhD thesis. We discuss Whitehead's process philosophy, how it connects to Platonism, and some of the modern implications of Whitehead's thought.",
    timestamps:
      "01:07 Introduction\n3:37 Who is Nathan Dufour?\n05:33 Music and philosophy\n10:54 Performance vs truth\n15:23 Decay of modern art and hip-hop\n33:11 What is classics?\n37:42 Origins of Western civilization\n43:04 Nathan's background\n47:31 Misconceptions about classics\n50:13 Middle-Ages history and information overload\n58:04 Platonic forms\n1:03:55 Timaeus book\n1:07:13 Plato, Pythagoras and mathematics\n1:09:07 Whitehead's mathematics and Platonism\n1:18:26 Whitehead's actual entities\n1:21:00 Interpretation of Plato\n1:24:42 Lack of mysticism in Whitehead\n1:31:11 The legacy of process philosophy\n1:41:03 Systematic vs unsystematic philosophy\n1:45:33 Sacredness and Whitehead\n1:51:48 Conclusion\n1:54:09 Music video: History of Science",
    apple_link:
      "https://podcasts.apple.com/si/podcast/nathan-dufour-music-ancient-greece-and-whitehead/id1512482918?i=1000539072802",
    spotify_link: "https://open.spotify.com/episode/081PMDbDp7kaiXHS8aaLDr?si=m77GWlDXTcGeO-LT03o_Xg",
    youtube_link: "https://www.youtube.com/watch?v=Qhueoc4hQr8",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/ZjI1NDg2NWYtYWMxNC00MGVkLTljODAtMDliMjliNTYxZWYw?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "The Science of Magic & Transformation",
    side_title: "Juensung Kim",
    youtube_id: "jlbwdKvS_Zo",
    description:
      'Michael Strevens teaches philosophy of science at New York University. His work revolves around the nature of science, covering topics such as scientific explanation, complex systems, and probability. In his book "The Knowledge Machine" he explains why science is so successful at creating knowledge and why it took so long for humans to come up with it.\n\nIn this episode, we talk about the origins of science, philosophy of science, the contributions and flaws of Karl Popper and Thomas Kuhn, what makes science special and some odd contradictions at the core of scientific thinking.',
    timestamps:
      "0:24 Introduction\n8:43 Magic as an outgroup practice\n19:26 The cognitive science of magic\n25:10 Talent for magic\n32:27 Shamanism and magic\n39:26 Ancient and modern medicine\n47:21 Embodiment and experience\n49:07 Astrology\n1:00:33 The importance of meditation and magic boundaries\n1:10:35 The interplay of meditation, hypnosis and trance\n1:15:20 Duality of psychedelics and the meaning crisis\n1:23:53 Modern wisdom seeking\n1:30:12 What creates the desire for personal growth\n1:38:19 Psychedelics and personal aspirations\n1:44:16 Replacing magic in modern society\n1:47:51 Conclusion",
    apple_link:
      "https://podcasts.apple.com/si/podcast/juensung-kim-the-science-of-magic-transformation/id1512482918?i=1000531475359",
    spotify_link: "https://open.spotify.com/episode/0dyxz0H2IcsZznyaxr9WcO?si=JmhF_PHmS-Oall4vn28mGQ",
    youtube_link: "https://www.youtube.com/watch?v=jlbwdKvS_Zo",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/ZTcwZDU2YjYtMGFhNy00ODhmLTkxMzAtOGE0OWE1Yjk4ZDg5?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Dialogos, Wisdom, and Science",
    side_title: "John Vervaeke",
    youtube_id: "cCaGrBaiGZo",
    description:
      'John Vervaeke is the author of the famous YouTube series "Awakening from the Meaning Crisis". He is an Associate Professor at the University of Toronto and he is the director of the Cognitive Science program in the Consciousness and Wisdom Studies Laboratory. He has a vast body of scientific work related to consciousness, mindfulness, flow, and wisdom. In this episode, we cover some of John\'s life, the importance of dialogos, and the relationship between science and spirituality.',
    timestamps:
      "01:21 The origin of the Anagoge Podcast\n03:14 What is dialogos and what has John gotten from it\n09:39 Losing dialogos online and in podcasts\n16:03 John's intellectual path in science and religion\n27:00 Bridging the scientific and religious worldviews with wisdom\n33:40 Participatory vs propositional knowledge from mystical experiences\n42:36 The problem of self-selection within an ecology of spiritual practices\n48:24 The lag of science for spiritual practice\n53:08 Trade-offs from new conceptual vocabulary and the role of the imaginal.\n1:02:12 Reaching John's intellectual milestone\n1:07:36 Avoiding computation in CogSci programs\n1:09:53 Appreciation of John's work ",
    apple_link:
      "https://podcasts.apple.com/si/podcast/john-vervaeke-dialogos-wisdom-and-science/id1512482918?i=1000510085400",
    spotify_link: "https://open.spotify.com/episode/5FTKCgHGJGXEMwhnGwCz1x?si=B0Kvb7gxR42Sz9vW2LHVyA",
    youtube_link: "https://www.youtube.com/watch?v=cCaGrBaiGZo",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/NWI1NmExOGYtODFlNC00NDM2LWIyYzEtMDA4ZmEwNjVlMDYy?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Religious Symbolism",
    side_title: "Jonathan Pageuau",
    youtube_id: "k1ysFfBs87U",
    description:
      " Jonathan Pageau is a carver who specializes in Eastern Orthodox Icons and other traditional Christian images. He graduated with distinction from the Painting and Drawing program at Concordia University in Montreal and has recently gained popularity on YouTube by discussing symbolic thought from Christianity and its expression in modern culture. In this episode, we cover a bit of his personal history, early Greek thought in relationship to Christianity, what love means, how reality unfolds, and more.",
    timestamps:
      "0:26 Introduction\n2:42 The early life of Jonathan as a carver and his religious journey\n10:22 Philosophical background\n16:35 Biblical scholarship\n20:32 Plato and Aristotle's role in Christianity\n34:27 The problem of perennialism\n44:30 Love in Christianity\n47:55 Logic, love and fractals\n53:53 Problems with secular spirituality\n56:48 Mystical experiences in Christianity\n1:03:17 Movie and novel recommendations for symbolism",
    apple_link:
      "https://podcasts.apple.com/si/podcast/jonathan-pageau-religious-symbolism/id1512482918?i=1000491478586",
    spotify_link: "https://open.spotify.com/episode/5DygSitJSMyhiuRRD631hE?si=J8RAtU66Tmqr9RcwW2H2qQ",
    youtube_link: "https://www.youtube.com/watch?v=k1ysFfBs87U",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/ZGU0M2RhMjgtNmYxNC00MzVmLWIwOGMtYjNjOTdkY2FhNzgz?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "The Psychology and Evolution of Religion",
    side_title: "Azim Shariff",
    youtube_id: "UJkPWObh7b0",
    description:
      "Dr. Azim Shariff is a social and moral psychologist whose research focuses on morality and religion. He also has some more recent work on the ethics of automation and how people deal with the ethical dilemmas of self-driving cars. In this episode, we talk mostly about the psychology of religion through the lens of cultural evolutio",
    timestamps:
      "1:44 how Azim got into the psychology of religion\n3:11 connection between religion and morality\n05:34 competing perspectives on the emergence of moralistic monotheism\n14:09 how do we define what is adaptive in cultural evolution?\n20:26 adaptive value of micro and macro patterns of religious belief\n28:12 religion's adaptive value over time\n42:20 the aspects of religion that go beyond belief\n50:03 cultural backgrounds that influence religious belief\n56:17 the current scientific view of group selection\n1:04:29 how religion detaches from traditional values\n1:14:06 how religious people view the field of psychology of religion\n1:16:27 conflict between science and religion\n1:21:29 folk economics\n1:24:10 bikini selfies and income inequality\n1:27:47 paper controversy regarding religiosity, crime, and IQ",
    apple_link:
      "https://podcasts.apple.com/si/podcast/azim-shariff-the-psychology-and-evolution-of-religion/id1512482918?i=1000487534265",
    spotify_link: "https://open.spotify.com/episode/07q0i7CfmFrCkQ9tXmxyMe?si=3NUR_wSFTN2dX8SQfoCe0A",
    youtube_link: "https://www.youtube.com/watch?v=UJkPWObh7b0",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/OTg0ZWNkOGQtMDYyYy00NjJiLWI5ZWItNzg5NjQ0MTRiOGVm?sa=X&ved=0CAUQkfYCahcKEwiAwd_VibeAAxUAAAAAHQAAAAAQAQ",
  },
  {
    title: "Collective Knowledge and Overcoming Ignorance",
    side_title: "Steven Sloman",
    youtube_id: "IqqBCUkdP84",
    description:
      "In the 4th episode of our podcast, we finally get into some psychology. I had a very insightful conversation with Dr. Steven Sloman. He received his Ph.D. in Psychology from Stanford University. He is a cognitive scientist who studies how people think, particularly collective cognition. He wrote a book with Phil Fernbach titled The Knowledge Illusion: Why We Never Think Alone. We cover a fair bit in this episode, ranging from computational and alternative models of cognitive science, consciousness, his book knowledge illusion, the current age of information, the problem and reliability of expertise, and more.",
    timestamps:
      "01:45 computational and other models of cognitive science\n9:06 the hard problem of consciousness from a cognitive science perspective\n18:00 what is so special about Steven's book\n21:13 what is the knowledge illusion\n31:57 the evolutionary origins of the knowledge illusion\n35:56 evolutionary psychology and the illusion of knowledge in hunger gatherers\n44:35 the knowledge illusion with greater complexity and denser population\n50:20 age of information\n56:32 the problem of expertise\n1:00:45 rescuing expertise\n1:09:33 the illusion of knowledge in education\n1:12:13 importance of group work\n1:17:24 connection to Hugo Mercier's research\n1:24:36 unconscious competition and motivated reasoning\n1:29:35 long-term effects of exposition of ignorance\n1:33:14 individualistic vs collectivist societies\n1:40:44 culture differences of sacred values",
    apple_link:
      "https://podcasts.apple.com/si/podcast/steven-sloman-collective-knowledge-and-overcoming/id1512482918?i=1000486034386",
    spotify_link: "https://open.spotify.com/episode/3ZnocgtJ6uxzARCcNHjRWc?si=Yew2PAAZR9e_aAHCrUem7Q",
    youtube_link: "https://www.youtube.com/watch?v=IqqBCUkdP84",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/YjZlYzc5MzUtNWI2ZC00ZGJkLTgwNjYtMDBiZjcyMzE0ZTIw?sa=X&ved=0CAUQkfYCahcKEwjY5bG2p7eAAxUAAAAAHQAAAAAQCg",
  },
  {
    title: "Ontology, Mind, and Stories",
    side_title: "J.P. Marceau",
    youtube_id: "WAdJ8HM43To",
    description:
      "In this 3rd episode, I had a great conversation with Jean-Philippe Marceau. He holds a degree in computer science and has done a master's degree in philosophy about panpsychism as a response to the hard problem of consciousness. We talk about materialism, ontology, emergence, neo-platonism, Christianity, and more.",
    timestamps:
      "0:51 JP's journey from mathematics to philosophy\n9:40 Godel's theorems, cognitive biases and the myth of rationality\n13:36 Ancient Greek thought\n15:58 Brain division and propositional understanding\n17:51 Worldview difference from modern science and ancient philosophy\n21:07 Plato's theory of forms and its modern view\n22:17 The problem of consciousness for JP's worldview change\n31:49 The layman view of the mind problem\n34:30 Arguments for panpsychism\n38:14 How is consciousness unified?\n54:50 The importance of metaphysics in one's cosmology\n59:55 Kant's noumenal world and symbolism\n1:17:11 The ontology of stories and how it affects reality\n1:31:08 The abstract starts before the concrete\n1:36:21 Christ manifestation as abstract and concrete",
    apple_link:
      "https://podcasts.apple.com/si/podcast/j-p-marceau-ontology-mind-and-stories/id1512482918?i=1000479835781",
    spotify_link: "https://open.spotify.com/episode/5dGFtddvPN4WGmtWtskjuu?si=lI24HgfQTwKInq8_gqbQ0w",
    youtube_link: "https://www.youtube.com/watch?v=WAdJ8HM43To",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/YWMxMDIzOWYtNWRmZC00NGZkLTk0NDctZTcxOWE3MmFkNzY3?sa=X&ved=0CAUQkfYCahcKEwjY5bG2p7eAAxUAAAAAHQAAAAAQCg",
  },
  {
    title: "The Cognitive Science of Enlightenment and Mysticism",
    side_title: "Daniel Greig",
    youtube_id: "dKMU9r-WpI0",
    description:
      "This is the second episode of the Anagoge Podcast. Today we have Daniel Greig. The goal of this episode was to lay out an introduction to what the idea of enlightenment means, and how does that relate to both contemporary cognitive science and ancient spiritual traditions. How does the feeling of finally figuring a sodoku a block connect to speaking to an Angel? You will find out!",
    timestamps:
      "0:22 Introduction\n2:15 Psychedelic conferences\n9:00 Psychedelics in culture\n13:32 Cognitive science of insight\n19:15 Neuroscience of insight\n20:53 Naive realism\n27:46 Transformation experiences\n37:45 Wisdom and mystical states\n53:03 The role of imagination\n1:07:46 The cognitive continuum book",
    apple_link:
      "https://podcasts.apple.com/si/podcast/daniel-greig-the-cognitive-science-of/id1512482918?i=1000475294727",
    spotify_link: "https://open.spotify.com/episode/1thTYfoyzBoK2KI0SJ4wQW?si=Sk6bcb9cTJ6ZGIdA5U4Pmw",
    youtube_link: "https://www.youtube.com/watch?v=dKMU9r-WpI0",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/NWUwNWJkNGQtNmMyNy00NDRiLTkwYzctY2E4OTk3ZmY4MzAw?sa=X&ved=0CAUQkfYCahcKEwjY5bG2p7eAAxUAAAAAHQAAAAAQCg",
  },
  {
    title: "Morality, Psychedelics and Panpsychism",
    side_title: "Peter Sjöstedt-H",
    youtube_id: "tKDC4__LfTg",
    description:
      "For our first episode, the guest was Peter Sjöstedt-H, a philosopher of mind with a special interest in metaphysics and meta-ethics based on Whitehead and Nietzsche. He is currently doing a PhD on the topic of panpsychism. In this podcast, we discuss psychedelics, panpsychism, emergentism, mental causation, epiphenomenalism, materialism, and more.",
    timestamps:
      "0:22 Introduction\n2:42 Peter's introduction in Eastern Philosophy\n11:35 Morality and Mystical experiences\n31:04 Psychedelics\n39:32 Materialism\n53:54 Emergence and epiphenomenalism\n1:19:08 Whitehead metaphysics\n1:37:22 Prajna and mystical states",
    apple_link:
      "https://podcasts.apple.com/si/podcast/peter-sj%C3%B6stedt-h-morality-psychedelics-panpsychism/id1512482918?i=1000474293877",
    spotify_link: "https://open.spotify.com/episode/17roRvb2kvdCODuD0084Yk?si=8pjvbbwURbit5EZyPP9M8A",
    youtube_link: "https://www.youtube.com/watch?v=tKDC4__LfTg",
    google_link:
      "https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkcy5saWJzeW4uY29tLzI3MDEyNS9yc3M/episode/NTcxZjk0YTYtNTI5My00MmZhLTk3NWEtYmY2YTgxNzRiOWFl?sa=X&ved=0CAUQkfYCahcKEwjY5bG2p7eAAxUAAAAAHQAAAAAQCg",
  },
]

export default posts
